
public class Rational {

	public int numerator;
	public int denominator;

}
