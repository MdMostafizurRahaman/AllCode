package a1;

public class test {
	public static void main(String[] args) {
		User U1 = new User("Rakib", "Ahmed",0131111111);
		U1.display();
		Fruit f = new Fruit("Mango",3,10,100);
		f.display();
	}
}
