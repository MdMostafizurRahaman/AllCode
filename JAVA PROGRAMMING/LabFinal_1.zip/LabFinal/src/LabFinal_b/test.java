package LabFinal_b;

import java.util.Scanner;

public class test {
	public static void main(String[] args) {
		EncryptionUtil U1 = new EncryptionUtil();
		Scanner sca = new Scanner(System.in);
		String S1= sca.next();
		String S2 = sca.next();
		
		U1.display();
	}
}
