package LabFinal;

public class test {
	public static void main(String[] args) {
		AuthenticationInfo U1 = new AuthenticationInfo("djuwh%sbxb","Akib","Hello");
		U1.setURL("djuwh%sbxb");
		U1.setUsername("Akib");
		U1.setPassword("Hello");
		U1.display();
	}

}
