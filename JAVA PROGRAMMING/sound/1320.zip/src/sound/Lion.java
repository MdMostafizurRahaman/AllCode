package sound;

public class Lion extends sound{
	void sound() {
		soundmessage();
		System.out.println("Lion:Roar");
	}

}
