package sound;

public class cat extends sound{
	void sound() {
		soundmessage();
		System.out.println("Cat:Meou");
	}

}
