package sound;

public class Test {

	public static void main(String[] args) {
		sound s;
		s = new cat();
		s.sound();
		
		s = new Lion();
		s.sound();
	}
}
