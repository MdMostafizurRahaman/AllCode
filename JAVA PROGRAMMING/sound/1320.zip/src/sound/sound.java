package sound;

public abstract class sound {
	public void soundmessage() {
		System.out.println("Animal sound");
	}
	abstract void sound();

}
